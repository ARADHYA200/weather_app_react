import React, { useState } from 'react';
import WeatherCard from './components/WeatherCard';
import './App.css';

const API_KEY = "e6d10fd35bcfae687b47db0165823a75";

function App() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState("");

  const fetchWeather = async () => {
    try {
      setError("");
      const res = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_KEY}`);
      const data = await res.json();
      if (data.cod !== 200) {
        setError("City not found.");
        setWeather(null);
      } else {
        setWeather(data);
      }
    } catch (err) {
      setError("Error fetching data.");
      setWeather(null);
    }
  };

  return (
    <div className="app">
      <h1>Weather Dashboard</h1>
      <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="Enter city" />
      <button onClick={fetchWeather}>Get Weather</button>
      {error && <p className="error">{error}</p>}
      {weather && <WeatherCard weather={weather} />}
    </div>
  );
}

export default App;