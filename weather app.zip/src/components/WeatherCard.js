import React from 'react';

const WeatherCard = ({ weather }) => {
  const { name, main, weather: w, wind, sys } = weather;
  return (
    <div className="card">
      <h2>{name}, {sys.country}</h2>
      <p>🌡️ <strong>Temp:</strong> {main.temp} °C</p>
      <p>☁️ <strong>Weather:</strong> {w[0].description}</p>
      <p>💧 <strong>Humidity:</strong> {main.humidity}%</p>
      <p>🌬️ <strong>Wind:</strong> {wind.speed} m/s</p>
    </div>
  );
};

export default WeatherCard;
